﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json.Linq;
using RestSharp;
using RestSharp.Deserializers;
using RestSharp.Serialization.Json;
using System.Collections.Generic;
using System.Net;




namespace AccuWeatherTest.Tests
{
    [TestClass]
    public class TestSuite
    {

        #region Variables
        readonly string apikey = "xxxxx"; 
        readonly RestClient client = new RestClient("http://dataservice.accuweather.com");
        private readonly string url = "/forecasts/v1/daily/5day/";
        private JObject parsedRespons = new JObject();
        string locationKeyStockholm = "314929";
        string locationKeyAthens = "328217";
        #endregion

        #region Test Cases

        [TestMethod]
        public void WeatherIsColdInStockholm()
        {
            /*Acceptance criteria:	I expect the weather in January to be cold in Stockholm.
            Comment: I suppose that the acceptance criteria was not updated. You mean the temperature in the coming next 5 days?.
            Definition of cold: under 0 degrees is cold in winter. Both median maximum and minimum temperture should be under 0 degrees, not equal. */

            GetFiveDaysWeatherForecast(locationKeyStockholm);
            var maxUnderZero = IsMaxMedianTemperatureUnderZeroDegrees(parsedRespons);
            var minUnderZero = IsMinMedianTemperatureUnderZeroDegrees(parsedRespons);
            Assert.IsTrue(maxUnderZero & minUnderZero, "I expect both median maximum and minimum temperture be under 0 degrees");

        }

        [TestMethod]
        public void TemperatureInStockholmColderThanAthens()
        {
            /*Acceptance crriteria: I expect the maximum temperature in Stockholm to be colder than the temperature in Athens over the next 5 days;
            The criteria is not very clear. The temperature in Athens can be 5 days MAX or Min, or median.  In this case I believe that the Minimum in Athens 
            That we should compare to.*/


            GetFiveDaysWeatherForecast(locationKeyAthens);
            var minTempAthens = GetFiveDaysMinTemperature(parsedRespons);

            GetFiveDaysWeatherForecast(locationKeyStockholm);
            var maxTempStockholm = GetFiveDaysMaxTemperature(parsedRespons);

            Assert.IsTrue(maxTempStockholm < minTempAthens, "I expect the maximum temperature in Stockholm to be colder than the min temperature in Athens over the next 5 days");
        } 

        #endregion

        #region Help Functions
        public void GetFiveDaysWeatherForecast(string LocationKey)
        {
            RestRequest request = new RestRequest(url + LocationKey, Method.GET);
            request.AddParameter("apikey", apikey);
            var response = client.Execute(request);
            parsedRespons = JObject.Parse(response.Content);
        }

        public int GetFiveDaysMaxTemperature(JToken obs)
        {
            //Returns max temperature during 5 days.

            int max = (int)obs["DailyForecasts"][0]["Temperature"]["Maximum"]["Value"];

            for (int i = 1; i < 5; i++)
            {
                if (max < (int)obs["DailyForecasts"][i]["Temperature"]["Maximum"]["Value"])
                {
                    max = (int)obs["DailyForecasts"][i]["Temperature"]["Maximum"]["Value"];
                }
            }

            return max;
        }

        public int GetFiveDaysMinTemperature(JToken obs)
        {
            //Returns max temperature during 5 days.

            int min = (int)obs["DailyForecasts"][0]["Temperature"]["Minimum"]["Value"];

            for (int i = 1; i < 5; i++)
            {
                if (min > (int)obs["DailyForecasts"][i]["Temperature"]["Minimum"]["Value"])
                {
                    min = (int)obs["DailyForecasts"][i]["Temperature"]["Minimum"]["Value"];
                }
            }

            return min;
        }

        public bool IsMaxMedianTemperatureUnderZeroDegrees(JToken obs)
        {
            var sum = 0;

            for (int i = 0; i < 5; i++)
            {
                sum += (int)obs["DailyForecasts"][i]["Temperature"]["Maximum"]["Value"];
            }

            return (sum / 5) < 32;
        }

        public bool IsMinMedianTemperatureUnderZeroDegrees(JToken obs)
        {
            var sum = 0;

            for (int i = 0; i < 5; i++)
            {
                sum += (int)obs["DailyForecasts"][i]["Temperature"]["Minimum"]["Value"];
            }

            return (sum / 5) < 32;
        }

        #endregion

    }
}
